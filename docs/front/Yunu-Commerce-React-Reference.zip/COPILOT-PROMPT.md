# Prompt para o GitHub Copilot

Implemente o frontend React do YUNU Commerce dentro da solution existente, reproduzindo fielmente o pacote visual anexado `yunu-product-proposal-react-reference`.

Antes de alterar qualquer arquivo, inspecione:

- a estrutura real da solution;
- o formato da solution (`.sln` ou `.slnx`);
- os padrões de projetos em `src/Hosts`;
- o endpoint `POST /api/catalog/product-proposals`;
- o endpoint `GET /api/catalog/product-proposals/{proposalId}`;
- os DTOs HTTP reais de criação e consulta;
- a configuração atual de CORS da API.

Não redesenhe a interface e não substitua o CSS por outro design system. O HTML/JSX, o CSS, os componentes e a experiência visual do pacote anexado são a referência aprovada e devem ser preservados.

## Projeto

Crie:

```text
src/Hosts/Yunu.Commerce.Web
```

Tecnologias:

```text
React
TypeScript
Vite
CSS puro
```

Não utilizar Next.js, Tailwind, Bootstrap ou Material UI nesta etapa.

Integre o projeto à solution da maneira compatível com a estrutura encontrada. Se a solution aceitar `.esproj`, crie e adicione o projeto seguindo o padrão suportado pelo Visual Studio 2022. Caso contrário, mantenha o projeto Vite em `src/Hosts` e adicione-o como solution folder/itens da solução sem quebrar o build .NET.

## Referência obrigatória

Use diretamente estes arquivos anexados:

```text
design-reference.html
src/styles/yunu-commerce.css
src/components/TopBar.tsx
src/components/SideRail.tsx
src/components/CatalogChat.tsx
src/components/ProductProposalCard.tsx
src/components/SkuProposalCard.tsx
src/components/SkuAttributeItem.tsx
src/components/ProposalResult.tsx
src/components/ProposalReviewBar.tsx
src/models/productProposal.ts
src/api/productProposalsApi.ts
src/mock/productProposal.mock.ts
src/App.tsx
```

Preserve:

- cores;
- espaçamentos;
- tipografia;
- gradientes;
- sombras;
- cards;
- barra lateral;
- cabeçalho;
- chat;
- animação dos três pontos;
- card do produto acima;
- cards dos SKUs abaixo;
- grid de atributos;
- comportamento responsivo;
- acessibilidade e foco por teclado.

## Fluxo funcional

Implementar:

```text
Usuário digita a intenção
→ POST /api/catalog/product-proposals
→ estado de loading “Preparando sua proposta”
→ recebe proposalId
→ GET /api/catalog/product-proposals/{proposalId}
→ renderiza ProductProposalCard
→ renderiza um SkuProposalCard para cada SKU
```

Se o `POST` real já devolver `product`, `skus`, `source` e `resolution`, utilizar diretamente essa representação e não executar o GET adicional.

Endpoint base em desenvolvimento:

```text
https://localhost:7241
```

Configurar por variável:

```env
VITE_YUNU_API_BASE_URL=https://localhost:7241
VITE_USE_MOCK=false
```

Nunca espalhar a URL da API pelos componentes.

## Componentização

Manter no mínimo:

```text
src/
├── api/
│   └── productProposalsApi.ts
├── components/
│   ├── TopBar.tsx
│   ├── SideRail.tsx
│   ├── CatalogChat.tsx
│   ├── ProductProposalCard.tsx
│   ├── SkuProposalCard.tsx
│   ├── SkuAttributeItem.tsx
│   ├── ProposalResult.tsx
│   └── ProposalReviewBar.tsx
├── mock/
│   └── productProposal.mock.ts
├── models/
│   └── productProposal.ts
├── styles/
│   └── yunu-commerce.css
├── App.tsx
└── main.tsx
```

Não colocar toda a página em um único componente.

## Mapeamento dos dados

O card do produto deve exibir:

- status;
- nome sugerido, com fallback para o nome da categoria;
- descrição, com fallback neutro;
- categoria Google;
- caminho completo;
- Google Category ID;
- estratégia de resolução;
- similaridade ou rerank confidence;
- marca;
- família;
- locale;
- data de criação.

Não inventar marca, família, código ou GTIN. Usar:

```text
A definir
Não informado
```

Cada SKU deve possuir seu próprio card e exibir:

- posição SKU 01, SKU 02 etc.;
- código sugerido;
- GTIN;
- ID interno da proposta;
- quantidade de atributos;
- todos os atributos resolvidos.

Para cada atributo, priorizar o valor nesta ordem:

```text
optionName
typedValue.displayValue
normalizedValue
rawValue
```

O ícone visual do atributo deve variar por `dataType`:

```text
Enum → enum
Measurement → medida
demais → texto
```

## Estados da interface

Implementar corretamente:

- estado inicial;
- input vazio;
- contador `0/2000`;
- envio por botão;
- envio por `Ctrl+Enter` e `Cmd+Enter`;
- loading;
- sucesso;
- erro `400`;
- erro `422`;
- erro `503`;
- erro de conexão;
- cancelamento da requisição anterior com `AbortController`;
- múltiplos SKUs;
- proposta sem nome ou descrição;
- proposta sem atributos.

Não usar `setTimeout` no fluxo real. Ele só pode existir no modo mock.

## CORS na API

Configure uma policy nomeada no Host da API somente se ainda não existir uma equivalente.

As origens de desenvolvimento devem vir de configuração, incluindo o endereço real do Vite, normalmente:

```text
http://localhost:5173
https://localhost:5173
```

Não utilizar `AllowAnyOrigin` junto com credenciais.

Preservar a ordem correta do middleware e não alterar segurança ou autenticação além do necessário para o ambiente local.

## HTTPS local

A API usa certificado local em:

```text
https://localhost:7241
```

Não desabilitar validação TLS no código do browser. Documente que o certificado de desenvolvimento ASP.NET deve estar confiável na máquina.

## Botões ainda não implementados

Os botões abaixo devem permanecer visíveis, mas desabilitados ou claramente não operacionais enquanto não existirem endpoints:

```text
Editar detalhes
Editar SKU
Salvar para depois
Confirmar e criar produto
```

Não simular sucesso e não criar chamadas para endpoints inexistentes.

## Testes

Criar testes com a biblioteca já adotada pelo projeto ou, se não houver frontend ainda, Vitest + React Testing Library.

Testar:

1. renderização inicial;
2. botão desabilitado com input vazio;
3. contador de caracteres;
4. envio da intenção;
5. loading;
6. POST seguido de GET para o contrato atual;
7. uso direto do POST quando vier a proposta completa;
8. renderização do produto;
9. renderização de um ou vários SKUs;
10. valores Text, Enum e Measurement;
11. erros 400, 422, 503 e conexão;
12. navegação por teclado.

Os testes não devem chamar a API, MongoDB ou Azure reais.

## Restrições

Não alterar nesta tarefa:

- Domain;
- ProductProposal Aggregate;
- MongoDB;
- RAG;
- embeddings;
- reranking;
- prompts;
- criação canônica de Product/Sku;
- endpoint de confirmação.

No backend, alterar apenas o CORS se necessário.

## Validação

Ao concluir:

1. executar `npm install`;
2. executar o build do frontend;
3. executar testes do frontend;
4. executar o build da solution .NET para garantir que nada foi quebrado;
5. informar todos os arquivos criados e alterados;
6. informar a URL local do frontend;
7. mostrar como iniciar API e frontend simultaneamente no Visual Studio 2022;
8. confirmar que o layout permanece fiel ao pacote anexado;
9. confirmar que nenhum endpoint inexistente foi chamado;
10. confirmar que nenhum dado foi inventado no frontend.

Antes de implementar, adapte apenas contratos e caminhos aos tipos reais encontrados na solution. Não redesenhe a interface e não crie uma arquitetura paralela.
