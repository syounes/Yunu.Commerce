# YUNU Commerce AI — Product Proposal Frontend Reference

Pacote de referência do layout aprovado para implementação dentro da solução `Yunu.Commerce`.

## Conteúdo

- `design-reference.html`: versão HTML estática do layout completo.
- `src/styles/yunu-commerce.css`: CSS integral, responsivo e sem Tailwind.
- `src/components`: componentes React/TypeScript separados.
- `src/models/productProposal.ts`: contratos TypeScript do backend.
- `src/api/productProposalsApi.ts`: cliente do POST + GET de propostas.
- `src/mock/productProposal.mock.ts`: massa realista para desenvolvimento visual.
- `COPILOT-PROMPT.md`: instrução completa para o Copilot adaptar o pacote à solution.

## Executar isoladamente

```bash
npm install
cp .env.example .env.development
npm run dev
```

Para usar a API real:

```env
VITE_YUNU_API_BASE_URL=https://localhost:7241
VITE_USE_MOCK=false
```

## Contrato atual suportado

O cliente suporta dois formatos:

1. `POST` devolve apenas `proposalId`, seguido de `GET /{proposalId}`;
2. `POST` futuro devolve a proposta completa no próprio `201 Created`.

## Observação

Os botões de edição e confirmação são visuais nesta etapa. Não simular sucesso enquanto os respectivos endpoints não existirem.
